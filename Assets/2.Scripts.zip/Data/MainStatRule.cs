using AYellowpaper.SerializedCollections;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

[Serializable]
public class MainStatRule
{
    [Header("���� ���Ⱥ� ���� ���� ������")]
    [SerializeField] private SerializedDictionary<SubStatType, float> subStatPerPointDic = new SerializedDictionary<SubStatType, float>();
    [SerializeField] private LocalizedString statName;    //�̸�

    public IReadOnlyDictionary<SubStatType, float> SubStatPerPointDic { get => subStatPerPointDic; }
    public LocalizedString StatName { get => statName; }
}