using System;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    #region GameSaveData
    GameSaveData saveData = new GameSaveData();
    public GameSaveData SaveData { get { return saveData; } set { saveData = value; } }
    #endregion

    #region �ð�
    public event Action<int> OnTimeAdvanced;           // ������ �ð�
    public event Action<int> OnDayChanged;            // ��¥ �����
    public event Action<int, int> OnClockChanged;     // ���� �ð�

    public int Day { get; private set; }
    public int Hour { get; private set; }
    public int Minute { get; private set; }

    public void AdvanceMinutes(int minutes)
    {
        if (minutes <= 0)
            return;

        int totalMinutes = (Day - 1) * 1440 + Hour * 60 + Minute + minutes;

        // ��ü ��� �ϼ��� �Ϸ� �� �� ���
        int newDayIndex = totalMinutes / 1440;
        int minutesOfDay = totalMinutes % 1440;

        int oldDay = Day;
        Day = newDayIndex + 1;

        // �Ϸ簡 �Ѿ ��쿡�� �̺�Ʈ �߻�
        if (Day != oldDay)
            OnDayChanged?.Invoke(Day);

        Hour = minutesOfDay / 60;
        Minute = minutesOfDay % 60;

        OnTimeAdvanced?.Invoke(minutes);
        OnClockChanged?.Invoke(Hour, Minute);
    }
    public int GetTotalTime()
    {
        return (Day - 1) * 1440 + (Hour * 60) + (Minute);
    }
    #endregion
}
