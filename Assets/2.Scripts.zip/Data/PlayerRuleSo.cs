using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

[Serializable]
public class RankTier
{
    public LocalizedString rankName;
    public RankType rank;
    public int requestContribution;
}

[Serializable]
public class NeedRange
{
    public EffectSo effect;
    public NeedTier tier;
    [Range(0, 100)] public float minValue;
    [Range(0, 100)] public float maxValue;
}

[Serializable]
public class NeedData
{
    [SerializeField] private NeedType type;
    [SerializeField] private List<NeedRange> needRange = new List<NeedRange>();

    [Header("�ִ�/�ּ�/���۰�")]
    [SerializeField] private float maxValue = 100f;
    [SerializeField] private float minValue = 0f;
    [SerializeField] private float startValue = 100f;

    [Header("�ڵ� ��ȭ��(��/����)")]
    [SerializeField] private float reducePerMinute = 1f;

    public NeedType Type => type;
    public float MaxValue => maxValue;
    public float MinValue => minValue;
    public float StartValue => startValue;
    public float ReducePerMinute => reducePerMinute;

    public NeedTier GetTierFromValue(float value)
    {
        foreach (NeedRange need in needRange)
        {
            if (value >= need.minValue && value <= need.maxValue)
                return need.tier;
        }
        return NeedTier.Normal;
    }

    public EffectSo GetEffectFromTier(NeedTier tier)
    {
        foreach (NeedRange need in needRange)
        {
            if (need.tier == tier)
                return need.effect;
        }
        return null;
    }
}

[CreateAssetMenu(menuName = "Game/Rule/PlayerRule", fileName = "PlayerRuleSo")]
public class PlayerRuleSo : ScriptableObject
{
    [Header("�ʱ� ���� ������ ���� ����Ʈ")]
    [SerializeField] private int startPoint;

    [Header("������ ����")]
    [SerializeField] private int levelUpPoint;

    [Header("�屸")]
    [SerializeField] private List<NeedData> needRules = new List<NeedData>();

    [Header("���")]
    [SerializeField] private List<RankTier> rankTiers = new List<RankTier>();

    public int StartPoint { get => startPoint; }
    public int LevelUpPoint { get => levelUpPoint; }
    public IReadOnlyList<NeedData> NeedRules { get => needRules; }
    public IReadOnlyList<RankTier> RankTiers { get => rankTiers; }
}