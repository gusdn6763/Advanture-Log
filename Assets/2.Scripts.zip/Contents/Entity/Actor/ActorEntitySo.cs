
public class ActorEntitySo : BaseEntitySo
{
}