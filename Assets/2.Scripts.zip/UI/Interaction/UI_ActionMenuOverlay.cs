using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class UI_ActionMenuOverlay : MonoBehaviour, IPointerDownHandler
{
    private UI_ActionMenuBar actionMenuBar;

    public void Init()
    {
        actionMenuBar = GetComponentInChildren<UI_ActionMenuBar>();

        actionMenuBar.Init();
        gameObject.SetActive(false);
    }

    public void Open(BaseEntity target)
    {
        List<ActionMenuSo> targetMenus = target.ActionMenuList;

        if (targetMenus.Count == 0)
            return;

        gameObject.SetActive(true);                         // ����Ŀ(�θ�) ON
        actionMenuBar.OpenMenu(target, targetMenus);        // ���� ����
    }

    public void Close()
    {
        gameObject.SetActive(false);         // ����Ŀ(�θ�) OFF => �ڽ� �ڵ� OFF
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        Close();
    }
}