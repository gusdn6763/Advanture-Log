using System;
using UnityEngine;
using UnityEngine.Localization;

[Serializable]
public class SubStatRule
{
    [SerializeField] private LocalizedString statName;    //�̸�
    [SerializeField] private StatDisplayType displayType; //% ����
    [SerializeField] private float maxValue;              //���� ���� �ִ�ġ

    public LocalizedString StatName { get => statName; }
    public StatDisplayType DisplayType { get => displayType; }
    public float MaxValue { get => maxValue; }
}