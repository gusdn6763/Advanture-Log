using AYellowpaper.SerializedCollections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu(menuName = "Game/Entity/Player", fileName = "Player")]
public class PlayerSo : ActorEntitySo
{
    [Header("ĳ���� ����â ���� ����")]
    [SerializeField] private LocalizedString jobDescription;

    [Header("�⺻ ���� ����")]
    [SerializeField] private SerializedDictionary<MainStatType, int> baseMainStatDic;

    [Header("�⺻ ���� ����")]
    [SerializeField] private SerializedDictionary<SubStatType, float> baseSubStatDic;

    [Header("�⺻ ��ų")]
    [SerializeField] private List<SkillSo> baseSkillList;

    public LocalizedString JobDescription { get => jobDescription; }
    public IReadOnlyDictionary<MainStatType, int> BaseMainStatDic { get => baseMainStatDic; }
    public IReadOnlyDictionary<SubStatType, float> BaseSubStatDic { get => baseSubStatDic; }
    public IReadOnlyList<SkillSo> BaseSkillList { get => baseSkillList; }
}