using UnityEngine;

public static class StringUtil
{
    public static string FormatValueForDisplay(float value, StatDisplayType displayType)
    {
        bool isPercent = displayType == StatDisplayType.Percent;

        // ����ó�� ���̸� ������
        float r = Mathf.Round(value);
        bool intLike = Mathf.Abs(value - r) < 0.0001f;

        string number = intLike ? ((int)r).ToString() : value.ToString("0.#");
        return isPercent ? $"{number}%" : number;
    }
}