public class MonsterSo : ActorEntitySo
{
}