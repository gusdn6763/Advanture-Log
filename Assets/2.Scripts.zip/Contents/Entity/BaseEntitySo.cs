using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

public abstract class BaseEntitySo : ScriptableObject
{
    public string Id { get; private set; } = string.Empty;

    [Header("�޴�")][SerializeField] private List<ActionMenuSo> actionMenus = new List<ActionMenuSo>();
    [Header("�̸�")] [SerializeField] protected LocalizedString objectNameLocalized;  //�÷��̾�� objectName�� ������� ����
    [Header("����-����")] [SerializeField] private LocalizedString descriptionLocalized;
    [Header("�̹���")][SerializeField] private Sprite entityImage;
    [Header("������")][SerializeField] private GameObject entityPrefab;

    public virtual bool UsesLocalizedName { get => true; } // �⺻: �ٱ��� ���
    public List<ActionMenuSo> ActionMenus { get => actionMenus; }
    public LocalizedString ObjectNameLocalized { get => objectNameLocalized; }
    public LocalizedString DescriptionLocalized { get => descriptionLocalized; }
    public Sprite EntityImage { get => entityImage; }
    public GameObject EntityPrefab { get => entityPrefab; }

    public void SetId(string id)
    {
        if (string.IsNullOrEmpty(Id))
        {
            Id = id;
            return;
        }

        if (Id == id)
            return;

        Debug.LogError($"Id �� �Ҵ�:{Id} -> {id}");
    }
}